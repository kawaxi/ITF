<?php
// classes/EmailTracker.php

class EmailTracker {
    private $mysql; // mysql resource connection   
    
    /**
     * Initialize the EmailTracker.
     * In this class, we are also connecting to the 
     * MySQL server.  In a larger project, connections would
     * be managed by a separate Database abstraction
     * class
	 * 
	 * @param the id of the email campaign
     */
    public function __construct($campaignID, $settings) {
        // connect to mysql server.  
        $this->mysql = new mysqli(
            $settings['server'],
            $settings['username'],
            $settings['password'],
            $settings['schema']);
        if ($this->mysql->connect_errno) {
            throw new Exception("MySQL connection error: ".$this->mysql->connect_errno);
        }
               
    }
    
    public function __destruct() {
        $this->mysql->close();
    }
    
    /**
     * Record that a client has opened the email in the Database
     */
    function openedBy($campaignID,$subscriptionID) {
        $sql = "insert into `".get_class($this)."` ";
        $sql .= "(campaignID, subscriptionID) ";
        $sql .= " values ";
        $sql .= "('".$campaignID."','".$subscriptionID."')";
        
        $result = $this->mysql->query($sql);
        if (!$result) {
            throw new Exception("MySQL Query Error: ".$this->mysql->error);
        }
    }
}

?>
