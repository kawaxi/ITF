<?php
    // settings.php
    
    $settings['mysql']['server'] = '127.0.0.1';
    $settings['mysql']['username'] = 'root';
    $settings['mysql']['password'] = 'SecureCode@Intlabs';
    $settings['mysql']['schema'] = 'tracker_example';
    
?>
